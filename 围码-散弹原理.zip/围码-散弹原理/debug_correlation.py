import numpy as np
import pandas as pd
import os

def check_correlation():
    # Load history
    history_path = r"D:\Dpanqianyi\Python-Project\data\kl8_history_final.txt"
    with open(history_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    matrix = np.zeros((80, 80))
    total_periods = 0
    
    for line in lines:
        try:
            parts = line.strip().split(',')
            nums_str = [p for p in parts if p.startswith('numbers:')][0]
            nums = [int(n) for n in nums_str.replace('numbers:', '').split('-')]
            for i in range(len(nums)):
                for j in range(i + 1, len(nums)):
                    matrix[nums[i]-1, nums[j]-1] += 1
                    matrix[nums[j]-1, nums[i]-1] += 1
            total_periods += 1
        except:
            continue
            
    # Normalized correlation
    # Prob(A and B) / Prob(A) * Prob(B)? Or just count?
    # Simple count normalized by total periods
    avg_cooc = np.mean(matrix)
    max_cooc = np.max(matrix)
    min_cooc = np.min(matrix)
    
    print(f"Total periods: {total_periods}")
    print(f"Avg Co-occurrence: {avg_cooc:.2f}")
    print(f"Max Co-occurrence: {max_cooc}")
    print(f"Min Co-occurrence: {min_cooc}")
    
    # Expected co-occurrence for random:
    # 20/80 * 19/79 * total_periods
    expected = (20/80) * (19/79) * total_periods
    print(f"Expected Co-occurrence (Random): {expected:.2f}")

if __name__ == "__main__":
    check_correlation()
