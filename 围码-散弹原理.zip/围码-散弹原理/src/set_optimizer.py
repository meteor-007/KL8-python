import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from typing import List

class SingularitySetSearcher:
    """
    V10.0 “奇点爆发”搜索器: 使用多起点模拟退火搜索 (Multi-start Simulated Annealing)。
    目标: 寻找在图网络中“共振最强”的 32 码核。
    """
    def __init__(self, correlation_matrix: np.ndarray, history_results: List[List[int]] = None):
        self.adj = correlation_matrix
        self.history = history_results if history_results else []
        # 计算高阶连通性 (二阶邻接矩阵)
        self.adj_2 = np.matmul(self.adj, self.adj)

    def energy_function(self, selected_indices: List[int], prob_app: np.ndarray) -> float:
        """
        能量函数: E = -(P_total * C_internal + PhysicsPenalty)
        """
        # 1. 总预测概率
        p_total = np.sum(prob_app[selected_indices])
        
        # 2. 内部高阶连通性 (紧密度)
        sub_adj = self.adj_2[np.ix_(selected_indices, selected_indices)]
        c_internal = np.sum(sub_adj) / (len(selected_indices) ** 2)
        
        # 3. 物理惩罚 (最近 5 期的和值、跨度分布)
        penalty = 0.0
        if len(self.history) >= 5:
            recent_5 = self.history[-5:]
            sums = [sum(h) for h in recent_5]
            spans = [max(h) - min(h) for h in recent_5]
            
            curr_sum = sum([i + 1 for i in selected_indices]) * (20/32) # 估算 20 码和值
            curr_span = max(selected_indices) - min(selected_indices)
            
            # 如果偏离均值太多，给予惩罚
            if abs(curr_sum - np.mean(sums)) > np.std(sums) * 2:
                penalty += 10.0
            if abs(curr_span - np.mean(spans)) > np.std(spans) * 2:
                penalty += 10.0
                
        return -(p_total * (1.0 + c_internal) - penalty)

    def optimize(self, prob_app: np.ndarray, target_size: int = 32, num_starts: int = 5, max_iter: int = 200) -> List[int]:
        best_set = []
        best_energy = float('inf')
        
        for _ in range(num_starts):
            # 随机初始解 (优先选择概率高的)
            current_indices = np.argsort(-prob_app)[:target_size + 10]
            current_set = list(np.random.choice(current_indices, target_size, replace=False))
            current_energy = self.energy_function(current_set, prob_app)
            
            T = 1.0
            cooling_rate = 0.95
            
            for _ in range(max_iter):
                # 随机替换一个号码
                new_set = current_set.copy()
                idx_to_remove = np.random.randint(0, target_size)
                # 寻找不在当前集合中的号码，优先选概率高的
                candidates = [i for i in np.argsort(-prob_app)[:50] if i not in current_set]
                if not candidates: break
                new_set[idx_to_remove] = np.random.choice(candidates)
                
                new_energy = self.energy_function(new_set, prob_app)
                
                # Metropolis 准则
                if new_energy < current_energy or np.random.rand() < np.exp((current_energy - new_energy) / T):
                    current_set = new_set
                    current_energy = new_energy
                    
                if current_energy < best_energy:
                    best_energy = current_energy
                    best_set = current_set.copy()
                
                T *= cooling_rate
                if T < 0.01: break
                
        return sorted([int(i + 1) for i in best_set])

class RL_CombinatorialOptimizer:
    """
    强化学习组合优化器：基于 Policy-Gradient 思想优化号码组合选择。
    奖励函数: R = exp(hits - 8)
    """
    def __init__(self, input_dim=161, learning_rate=0.001):
        # input_dim: 80 (prob_app) + 80 (cluster_feat) + 1 (r_base)
        self.policy_net = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.LeakyReLU(0.2),
            nn.Dropout(0.2),
            nn.Linear(256, 80),
            nn.Softmax(dim=-1)
        )
        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=learning_rate)

    def optimize(self, prob_app, cluster_feat, r_base, target_size=32):
        """
        根据当前状态，输出号码选择概率并进行采样。
        """
        state = np.concatenate([prob_app, cluster_feat, [r_base]])
        state_tensor = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
        
        # 策略网络输出每个号码作为“核心”的概率
        action_probs = self.policy_net(state_tensor)
        
        # 使用 Categorical 分布进行采样 (不放回采样 target_size 个)
        _, top_indices = torch.topk(action_probs, target_size)
        selected_indices = top_indices.squeeze().tolist()
        
        return sorted([int(i + 1) for i in selected_indices]), action_probs

    def calculate_reward(self, hits: int):
        """
        核心奖励函数：R = e^(hits - 8)
        当命中数达到 13 以上时，奖励爆炸。
        """
        return np.exp(hits - 8)

    def update_policy(self, action_probs, selected_indices, reward):
        """
        执行策略梯度更新
        """
        self.optimizer.zero_grad()
        indices_tensor = torch.tensor([idx - 1 for idx in selected_indices])
        log_probs = torch.log(action_probs[0, indices_tensor])
        loss = -(log_probs * reward).mean()
        loss.backward()
        self.optimizer.step()

class CombinatorialOptimizer:
    """
    传统组合优化器: 基于深度学习概率与号码共现矩阵，通过贪心算法优化号码组合。
    """
    def __init__(self, alpha: float = 1.0):
        self.alpha = alpha

    def optimize_set(self, prob_app: np.ndarray, correlation_matrix: np.ndarray, target_size: int = 32) -> List[int]:
        sorted_indices = np.argsort(-prob_app)
        seeds = sorted_indices[:10].tolist()
        remaining = sorted_indices[10:].tolist()
        
        while len(seeds) < target_size and remaining:
            best_score = -1.0
            best_idx = -1
            for idx in remaining:
                co_occurrence = np.mean([correlation_matrix[idx, s] for s in seeds])
                score = prob_app[idx] + self.alpha * co_occurrence
                if score > best_score:
                    best_score = score
                    best_idx = idx
            if best_idx != -1:
                seeds.append(best_idx)
                remaining.remove(best_idx)
            else:
                break
        return sorted([int(i + 1) for i in seeds])
