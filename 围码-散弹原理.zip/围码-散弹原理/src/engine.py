import mmh3
import math
import numpy as np
from typing import List, Tuple, Dict
from .models import (
    BASE_ANCHORS, BASE_ANCHOR_COORDS, KP, KI, KD, I_MAX, R_MIN, R_MAX, INITIAL_R_BASE, 
    WARMUP_PERIODS, TARGET_COVERAGE, TARGET_HITS, BETA, Q_MIN, Q_MAX, MU_MOMENTUM,
    SHARPNESS_FACTOR
)
from .utils import TorusGrid

class ScoringEngine:
    """
    Handles Gaussian scoring and dynamic truncation using Numpy.
    """
    @staticmethod
    def calculate_scores(anchor_coords: np.ndarray, r_base: float, offset: Tuple[float, float] = (0, 0), history_results: List[List[int]] = None, history_file: str = None) -> np.ndarray:
        # V5.1: 触发映射自检与更新
        TorusGrid.load_mapping(history_file=history_file)
        all_coords = TorusGrid.get_all_coords() # (80, 2)
        
        # Apply offset
        shifted_anchors = anchor_coords.copy()
        shifted_anchors[:, 0] = (shifted_anchors[:, 0] + offset[0]) % 10.0
        shifted_anchors[:, 1] = (shifted_anchors[:, 1] + offset[1]) % 8.0
        
        # Vectorized distance matrix (80, 20)
        dist_matrix = TorusGrid.torus_distance_matrix(all_coords, shifted_anchors)
        
        # Gaussian scores
        r_sq_2 = 2 * (r_base ** 2)
        # V4.0: 基础得分计算
        raw_scores = np.sum(np.exp(-(dist_matrix ** 2) / r_sq_2), axis=1)
        
        # V4.0: LocalHeatScore 权重叠加
        heat_scores = np.zeros(80)
        if history_results:
            recent_5 = history_results[-5:]
            for period_nums in recent_5:
                for n in period_nums:
                    if 1 <= n <= 80:
                        heat_scores[n-1] += 1.0
        
        final_heat_multiplier = heat_scores + 1.0
        raw_scores *= final_heat_multiplier

        # V4.0: 簇能量增强
        boosted_scores = raw_scores.copy()
        for i in range(80):
            neighbors = TorusGrid.get_neighbors(i+1)
            neighbor_indices = [n-1 for n in neighbors]
            neighbor_avg = np.mean(raw_scores[neighbor_indices])
            boosted_scores[i] *= (neighbor_avg ** SHARPNESS_FACTOR)
            
        return boosted_scores

    @staticmethod
    def calculate_density(scores: np.ndarray) -> float:
        max_score = np.max(scores)
        if max_score == 0:
            return 0.0
        return np.mean(scores / max_score)

    @staticmethod
    def calculate_q(density: float) -> int:
        if density == 0:
            return Q_MIN
        q = round(Q_MAX * density * BETA)
        return int(np.clip(q, Q_MIN, Q_MAX))

    @staticmethod
    def get_ranked_pool(scores: np.ndarray, q: int) -> Tuple[List[int], List[int]]:
        rounded_scores = np.round(scores, 8)
        indices = np.arange(1, 81)
        sort_idx = np.lexsort((indices, -rounded_scores))
        ranked_list = indices[sort_idx].tolist()
        enclosure_pool = ranked_list[:q]
        return ranked_list, sorted(enclosure_pool)

class BayesianController:
    """
    Bayesian prediction for barycenter projection.
    """
    @staticmethod
    def calculate_offset(history_results: List[List[int]]) -> Tuple[float, float]:
        if not history_results:
            return 0.0, 0.0
        
        all_coords = []
        for nums in history_results[-10:]: 
            for n in nums:
                all_coords.append(TorusGrid.get_coords(n))
        
        coords = np.array(all_coords) 
        x_angles = 2 * np.pi * coords[:, 0] / 10.0
        x_bary = (np.arctan2(np.mean(np.sin(x_angles)), np.mean(np.cos(x_angles))) % (2 * np.pi)) * 10.0 / (2 * np.pi)
        
        y_angles = 2 * np.pi * coords[:, 1] / 8.0
        y_bary = (np.arctan2(np.mean(np.sin(y_angles)), np.mean(np.cos(y_angles))) % (2 * np.pi)) * 8.0 / (2 * np.pi)
        
        offset_x = x_bary - 4.5
        offset_y = y_bary - 3.5
        return offset_x, offset_y

class MomentumPID:
    @staticmethod
    def update(
        current_r_base: float,
        integral: float,
        prev_error: float,
        momentum_v: float,
        last_pool: List[int],
        last_result: List[int],
        periods_processed: int
    ) -> Tuple[float, float, float, float, float]:
        if not last_pool or not last_result:
            return current_r_base, integral, prev_error, momentum_v, 0.0

        hits = len(set(last_pool) & set(last_result))
        coverage = hits / 20.0
        error = TARGET_COVERAGE - coverage

        if periods_processed < WARMUP_PERIODS:
            return INITIAL_R_BASE, 0.0, error, 0.0, coverage

        p_term = KP * error
        new_integral = max(-I_MAX, min(I_MAX, integral + error))
        i_term = KI * new_integral
        d_term = KD * (error - prev_error)
        
        raw_delta_r = p_term + i_term + d_term
        new_v = MU_MOMENTUM * momentum_v + (1 - MU_MOMENTUM) * raw_delta_r
        new_r_base = current_r_base + new_v
        new_r_base = max(R_MIN, min(R_MAX, new_r_base))
        
        return new_r_base, new_integral, error, new_v, coverage

class DynamicQAllocator:
    @staticmethod
    def allocate(confidences: List[float], total_q: int = Q_MAX) -> List[int]:
        confs = np.array(confidences)
        total_conf = np.sum(confs)
        if total_conf == 0:
            return [total_q // len(confidences)] * len(confidences)
        
        weights = confs / total_conf
        allocations = (weights * total_q).astype(int)
        
        diff = total_q - np.sum(allocations)
        if diff > 0:
            for i in range(diff):
                allocations[i % len(allocations)] += 1
        elif diff < 0:
            for i in range(abs(diff)):
                idx = np.argmax(allocations)
                allocations[idx] -= 1
                
        return allocations.tolist()

class MultiFocalEngine:
    """
    多焦聚焦架构 V6.0
    """
    @staticmethod
    def consensus_gate(prob_app: np.ndarray, prob_avoid: np.ndarray, s_bary: np.ndarray, last_hit_periods: List[int], current_period: int, strict: bool = True) -> np.ndarray:
        """
        ConsensusGate V6.1: 优化共识平衡与动态过滤
        V7.0: 增加 strict 参数支持对冲策略
        """
        # 1. 遗漏梯度 (0-1)
        omissions = np.array([current_period - p for p in last_hit_periods])
        omission_grad = np.clip(omissions / 40.0, 0, 1.0)

        # 2. 基础共识分数
        # 归一化输入
        s_b_norm = s_bary / (np.max(s_bary) + 1e-6)

        # 核心逻辑：(出现概率 * 0.6 + 重心分 * 0.4) * (1.1 - prob_avoid)
        # 增加遗漏弹性的非线性加持
        consensus = (prob_app * 0.6 + s_b_norm * 0.4) * (1.1 - prob_avoid)
        consensus *= (1.0 + 0.3 * omission_grad)

        # 3. 动态反向避雷 (V6.1)
        if strict:
            # 严格模式：排除前 20% 最可能不出的
            avoid_threshold = np.percentile(prob_avoid, 80)
            consensus[prob_avoid > max(0.7, avoid_threshold)] = 0.0
        else:
            # 宽松模式：仅排除极高概率不出的 (例如 > 0.92)
            consensus[prob_avoid > 0.92] = 0.0

        return consensus


    @staticmethod
    def get_barycenter_scores(anchors: np.ndarray, r_base: float, offset: Tuple[float, float], history_results: List[List[int]] = None, history_file: str = None) -> Tuple[np.ndarray, float]:
        scores = ScoringEngine.calculate_scores(anchors, r_base, offset, history_results=history_results, history_file=history_file)
        density = ScoringEngine.calculate_density(scores)
        conf = np.clip(1.2 - density, 0.4, 0.9)
        return scores, float(conf)

    @staticmethod
    def get_momentum_scores(coverage_history: List[float], anchors: np.ndarray, r_base: float, history_results: List[List[int]] = None, history_file: str = None) -> Tuple[np.ndarray, float]:
        if len(coverage_history) < 3:
            return np.ones(80) / 80.0, 0.3
        
        v1 = coverage_history[-1] - coverage_history[-2]
        v2 = (coverage_history[-1] - coverage_history[-2]) - (coverage_history[-2] - coverage_history[-3])
        conf = np.clip(0.5 + v1 * 3.0 + v2 * 1.5, 0.2, 0.8)
        
        drift_offset = (v1 * 8.0, v1 * 6.0)
        scores = ScoringEngine.calculate_scores(anchors, r_base * 1.2, offset=drift_offset, history_results=history_results, history_file=history_file)
        return scores, float(conf)

    @staticmethod
    def get_entropy_scores(last_hit_periods: List[int], current_period: int) -> Tuple[np.ndarray, float]:
        last_hits = np.array(last_hit_periods)
        cooldown = np.clip(current_period - last_hits, 0, 100)
        
        if np.max(cooldown) == 0:
            scores = np.ones(80) / 80.0
        else:
            scores = np.power(cooldown, 1.5)
            scores = scores / (np.sum(scores) + 1e-6)
            
        avg_cooldown = np.mean(cooldown)
        conf = np.clip(avg_cooldown / 15.0, 0.1, 0.4)
        return scores, float(conf)

    @staticmethod
    def get_dl_v6_scores(history_results: List[List[int]], s_bary: np.ndarray, last_hit_periods: List[int], current_period: int, strict: bool = True, loss_history: List[float] = None) -> Tuple[np.ndarray, np.ndarray, np.ndarray, float, np.ndarray, float]:
        """
        V6.0: 深度学习双塔共识焦 (V10.0 扩展: 支持奇点检测概率)
        """
        from .dl_model import predict_next
        if not history_results or len(history_results) < 10:
            return np.ones(80) / 80.0, np.ones(80) / 80.0, np.zeros(80), 0.1, np.array([0.25]*4), 0.0
        
        recent_10 = history_results[-10:]
        try:
            # V10.0: 调用 predict_next 获得 4 个返回值
            prob_app, prob_avoid, expert_weights, s_prob = predict_next(recent_10, loss_history=loss_history)
            consensus_scores = MultiFocalEngine.consensus_gate(prob_app, prob_avoid, s_bary, last_hit_periods, current_period, strict=strict)
            conf = 2.5
            return consensus_scores, prob_app, prob_avoid, float(conf), expert_weights, float(s_prob)
        except Exception as e:
            print(f"V10.0 态势集成推断失败: {e}")
            return np.ones(80) / 80.0, np.ones(80) / 80.0, np.zeros(80), 0.1, np.array([0.25]*4), 0.0

class AnchorEngine:
    @staticmethod
    def get_offset(period_id: int) -> int:
        return 0

    @staticmethod
    def generate_anchors(period_id: int) -> np.ndarray:
        offset = AnchorEngine.get_offset(period_id)
        dx = offset % 10
        dy = offset // 10
        coords = np.array(BASE_ANCHOR_COORDS, dtype=float)
        coords[:, 0] = (coords[:, 0] + dx) % 10.0
        coords[:, 1] = (coords[:, 1] + dy) % 8.0
        return coords
