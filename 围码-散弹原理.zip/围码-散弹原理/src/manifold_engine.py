import numpy as np
from sklearn.manifold import SpectralEmbedding, MDS
from sklearn.cluster import DBSCAN
import os

class ManifoldCollapseEngine:
    """
    流形塌缩引擎：将号码的高维特征投影到低维流形空间，识别潜在的号码塌缩簇。
    """
    def __init__(self, n_components=3, method='spectral'):
        self.n_components = n_components
        self.method = method
        if method == 'spectral':
            self.model = SpectralEmbedding(n_components=n_components, affinity='precomputed', random_state=42)
        else:
            self.model = MDS(n_components=n_components, dissimilarity='precomputed', random_state=42)

    def find_collapse_clusters(self, correlation_matrix: np.ndarray):
        """
        识别流形空间中距离骤减（高亲和度）的号码簇。
        """
        # 确保相关矩阵是对称的且在合理范围内
        affinity = (correlation_matrix + correlation_matrix.T) / 2.0
        np.fill_diagonal(affinity, 1.0)
        
        # 流形映射 (80 -> 3D)
        try:
            if self.method == 'spectral':
                coords = self.model.fit_transform(affinity)
            else:
                dist = 1.0 - affinity
                np.fill_diagonal(dist, 0)
                coords = self.model.fit_transform(dist)
        except Exception as e:
            print(f"Manifold embedding failed: {e}, using random coords.")
            coords = np.random.rand(80, self.n_components)

        # 在流形空间中使用 DBSCAN 寻找“塌缩”点簇
        # 这里的 eps 需要根据空间尺度调整，0.1 是一个经验值
        clustering = DBSCAN(eps=0.15, min_samples=2).fit(coords)
        labels = clustering.labels_

        clusters = []
        for label in set(labels):
            if label == -1: continue
            indices = np.where(labels == label)[0]
            clusters.append({
                "cluster_id": int(label),
                "members": (indices + 1).tolist(),
                "centroid": coords[indices].mean(axis=0).tolist(),
                "density": len(indices)
            })

        return coords, clusters

    @staticmethod
    def get_cluster_features(clusters, target_size=80):
        """
        将簇特征转化为号码权重补偿。
        """
        feat = np.zeros(target_size)
        for cluster in clusters:
            for member in cluster['members']:
                # 簇内成员获得权重加成，加成与其所在簇的密度正相关
                feat[member-1] += 0.1 * cluster['density']
        return feat
