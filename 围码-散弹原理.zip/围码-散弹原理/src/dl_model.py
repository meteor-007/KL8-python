import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import numpy as np
import os

# --- V7.0 新增: Focal Loss 损失函数 ---
class FocalLoss(nn.Module):
    """
    Focal Loss 旨在解决类别不平衡问题，通过减少易分类样本的权重，
    使模型更加专注于难分类的样本。
    """
    def __init__(self, alpha=0.25, gamma=2.0, reduction='mean'):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction

    def forward(self, inputs, targets):
        # 使用 sigmoid_cross_entropy_with_logits 的基础
        BCE_loss = F.binary_cross_entropy_with_logits(inputs, targets, reduction='none')
        pt = torch.exp(-BCE_loss) # pt 是预测概率
        F_loss = self.alpha * (1 - pt)**self.gamma * BCE_loss
        
        if self.reduction == 'mean':
            return torch.mean(F_loss)
        return torch.sum(F_loss)

# --- V7.0 新增: DCN 交叉网络层 ---
class CrossNetwork(nn.Module):
    """
    简单的交叉网络层 (Cross Network)，用于捕获特征间的显式交叉关系。
    公式: x_{l+1} = x_0 * (w * x_l) + b + x_l
    """
    def __init__(self, input_size):
        super(CrossNetwork, self).__init__()
        self.w = nn.Parameter(torch.randn(input_size, 1))
        self.b = nn.Parameter(torch.zeros(input_size))

    def forward(self, x):
        # x shape: (batch, seq, input_size)
        x0 = x
        # 矩阵乘法计算特征交叉
        # x * w -> (batch, seq, 1)
        xw = torch.matmul(x, self.w)
        x_next = x0 * xw + self.b + x
        return x_next

# --- V8.0 新增: 图卷积层 ---
class GraphConvolution(nn.Module):
    """
    图卷积层实现: x = relu(A_hat @ x @ W)
    """
    def __init__(self, in_features, out_features):
        super(GraphConvolution, self).__init__()
        self.weight = nn.Parameter(torch.FloatTensor(in_features, out_features))
        nn.init.xavier_uniform_(self.weight)

    def forward(self, x, adj):
        # x: (batch, nodes, in_features)
        # adj: (nodes, nodes)
        support = torch.matmul(x, self.weight)
        output = torch.matmul(adj, support)
        return F.relu(output)

# --- V9.0 新增: Meta-Critic 网络 ---
class MetaCritic(nn.Module):
    """
    元评论家网络：基于最近 5 期的损失分布，生成 4 个专家的动态权重系数。
    """
    def __init__(self, history_len=5, num_experts=4):
        super(MetaCritic, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(history_len, 32),
            nn.ReLU(),
            nn.Linear(32, num_experts),
            nn.Softmax(dim=-1)
        )

    def forward(self, loss_history):
        # loss_history shape: (batch, 5)
        return self.net(loss_history)

# --- V9.0 新增: 专家层 ---
class ExpertLayer(nn.Module):
    def __init__(self, input_dim, hidden_dim, expert_type='Hot'):
        super(ExpertLayer, self).__init__()
        self.type = expert_type
        self.fc = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LeakyReLU(0.2),
            nn.Dropout(0.3),
            nn.Linear(hidden_dim, 80)
        )

    def forward(self, x):
        return self.fc(x)

# --- V9.0 修改: RegimeEnsembleGAT (由 SingularityGAT 升级) ---
class RegimeEnsembleGAT(nn.Module):
    """
    态势集成图网络：集成 4 个专家层，并通过 Meta-Critic 实现动态权重分配。
    """
    def __init__(self, input_size=173, hidden_size=256, nhead=8, num_layers=4, dropout=0.4):
        super(RegimeEnsembleGAT, self).__init__()
        # 1. 骨干特征提取 (与 SingularityGAT 保持一致)
        self.cross_net = CrossNetwork(input_size)
        self.embedding = nn.Linear(input_size, hidden_size)
        encoder_layers = nn.TransformerEncoderLayer(
            d_model=hidden_size, 
            nhead=nhead, 
            dim_feedforward=hidden_size*4, 
            dropout=dropout, 
            batch_first=True
        )
        self.transformer_encoder = nn.TransformerEncoder(encoder_layers, num_layers=num_layers)
        
        self.node_dim = 64
        self.node_embedding = nn.Embedding(80, self.node_dim)
        self.gcn = GraphConvolution(self.node_dim, self.node_dim)
        self.gnn_fc = nn.Linear(80 * self.node_dim, hidden_size)
        
        # 2. V9.0: 专家层 (Ensemble)
        self.experts = nn.ModuleDict({
            'Hot': ExpertLayer(hidden_size, hidden_size // 2, 'Hot'),
            'Ice': ExpertLayer(hidden_size, hidden_size // 2, 'Ice'),
            'Signal': ExpertLayer(hidden_size, hidden_size // 2, 'Signal'),
            'Structure': ExpertLayer(hidden_size, hidden_size // 2, 'Structure')
        })
        
        # 3. V9.0: Meta-Critic
        self.meta_critic = MetaCritic(history_len=5, num_experts=4)
        
        # 4. V10.0: SingularityDetection 分支 (预测坍缩)
        self.singularity_detector = nn.Sequential(
            nn.Linear(hidden_size, 64),
            nn.ReLU(),
            nn.Linear(64, 1),
            nn.Sigmoid()
        )
        
        # 避雷层保持独立 (用于全局风险控制)
        self.fc_avoidance = nn.Sequential(
            nn.Linear(hidden_size, hidden_size // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_size // 2, 80)
        )
        
        self.register_buffer('adj_hat', self._load_and_normalize_adj())

    def _load_and_normalize_adj(self):
        adj_path = 'src/correlation_matrix.npy'
        if os.path.exists(adj_path):
            adj = np.load(adj_path)
        else:
            adj = np.eye(80)
        adj = adj + np.eye(80)
        rowsum = np.array(adj.sum(1))
        d_inv_sqrt = np.power(rowsum, -0.5).flatten()
        d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.
        d_mat_inv_sqrt = np.diag(d_inv_sqrt)
        adj_hat = d_mat_inv_sqrt @ adj @ d_mat_inv_sqrt
        return torch.FloatTensor(adj_hat)

    def forward(self, x, loss_history=None):
        # x: (batch, seq, 173)
        # loss_history: (batch, 5)
        
        # 骨干特征提取
        x_cross = self.cross_net(x)
        x_emb = self.embedding(x_cross)
        x_trans = self.transformer_encoder(x_emb)
        latent_trans = x_trans[:, -1, :]
        
        batch_size = x.size(0)
        nodes = torch.arange(80, device=x.device).unsqueeze(0).repeat(batch_size, 1)
        node_feats = self.node_embedding(nodes)
        gnn_out = self.gcn(node_feats, self.adj_hat)
        latent_gnn = self.gnn_fc(gnn_out.view(batch_size, -1))
        
        combined_latent = latent_trans + latent_gnn
        
        # V10.0: 奇点检测
        singularity_prob = self.singularity_detector(combined_latent)
        
        # V9.0: 专家加权逻辑
        if loss_history is None:
            # 默认平均加权
            weights = torch.full((batch_size, 4), 0.25, device=x.device)
        else:
            weights = self.meta_critic(loss_history) # (batch, 4)
        
        # 获取各专家输出
        expert_outputs = []
        for name in ['Hot', 'Ice', 'Signal', 'Structure']:
            expert_outputs.append(self.experts[name](combined_latent))
        
        # 堆叠专家输出: (batch, 4, 80)
        expert_outputs = torch.stack(expert_outputs, dim=1)
        
        # 加权融合: (batch, 1, 4) * (batch, 4, 80) -> (batch, 80)
        app_logits = torch.sum(expert_outputs * weights.unsqueeze(-1), dim=1)
        
        avoid_logits = self.fc_avoidance(combined_latent)
        
        return app_logits, avoid_logits, combined_latent, weights, singularity_prob

def get_features(nums, omissions):
    vec = np.zeros(80, dtype=np.float32)
    for n in nums:
        if 1 <= n <= 80: vec[n-1] = 1.0
    omission_vec = np.array(omissions, dtype=np.float32) / 100.0
    tails = np.zeros(10, dtype=np.float32)
    for n in nums: tails[n % 10] += 1.0
    tails /= 20.0
    sum_val = sum(nums)
    sum_norm = (sum_val - 210) / (1410 - 210)
    mean_norm = (sum_val / 20.0 - 10.5) / (70.5 - 10.5)
    sorted_nums = sorted(nums)
    consecutive_count = 0
    for i in range(len(sorted_nums) - 1):
        if sorted_nums[i+1] - sorted_nums[i] == 1: consecutive_count += 1
    consecutive_norm = consecutive_count / 19.0
    return np.concatenate([vec, omission_vec, tails, np.array([sum_norm, mean_norm, consecutive_norm], dtype=np.float32)])

def preprocess_data(file_path, seq_len=10, limit=2000):
    if not os.path.exists(file_path): raise FileNotFoundError(f"找不到历史数据文件: {file_path}")
    all_raw_nums = []
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()[::-1]
        for line in lines:
            if not line.strip(): continue
            try:
                parts = line.split(',')
                num_part = [p for p in parts if p.startswith('numbers:')][0]
                nums = [int(n) for n in num_part.replace('numbers:', '').split('-')]
                all_raw_nums.append(nums)
            except: continue
    if limit > 0: all_raw_nums = all_raw_nums[-(limit + seq_len + 1):]
    all_features = []
    current_omissions = [0] * 80
    for i in range(len(all_raw_nums)):
        nums = all_raw_nums[i]
        feat = get_features(nums, current_omissions)
        all_features.append(feat)
        new_omissions = [o + 1 for o in current_omissions]
        for n in nums:
            if 1 <= n <= 80: new_omissions[n-1] = 0
        current_omissions = new_omissions
    data_x, data_y_app, data_y_avoid = [], [], []
    for i in range(len(all_features) - seq_len):
        data_x.append(all_features[i : i + seq_len])
        target_nums = all_raw_nums[i + seq_len]
        app_target = np.zeros(80, dtype=np.float32)
        for n in target_nums:
            if 1 <= n <= 80: app_target[n-1] = 1.0
        data_y_app.append(app_target)
        data_y_avoid.append(1.0 - app_target)
    return torch.tensor(np.array(data_x)), torch.tensor(np.array(data_y_app)), torch.tensor(np.array(data_y_avoid))

# --- V7.0 新增: 对比损失计算 ---
def contrastive_loss(latent, y_app):
    """
    强迫同一个 batch 中 y_app 相似的样本其 latent 表示更接近。
    计算 y_app 间的余弦相似度作为目标相似度，让 latent 间的相似度逼近它。
    """
    # y_app 相似度矩阵 (batch, batch)
    y_norm = F.normalize(y_app, p=2, dim=1)
    sim_target = torch.matmul(y_norm, y_norm.T)
    
    # latent 相似度矩阵 (batch, batch)
    latent_norm = F.normalize(latent, p=2, dim=1)
    sim_latent = torch.matmul(latent_norm, latent_norm.T)
    
    # 对比损失: 均方误差
    loss = F.mse_loss(sim_latent, sim_target)
    return loss

def train_model(file_path, save_path='models/lstm_weights.pth', epochs=50, batch_size=32, seq_len=10, val_split=0.1):
    X, y_app, y_avoid = preprocess_data(file_path, seq_len=seq_len)
    val_size = int(len(X) * val_split)
    train_size = len(X) - val_size
    train_loader = DataLoader(TensorDataset(X[:train_size], y_app[:train_size], y_avoid[:train_size]), batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(TensorDataset(X[train_size:], y_app[train_size:], y_avoid[train_size:]), batch_size=batch_size)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    # V9.0: 使用 RegimeEnsembleGAT
    model = RegimeEnsembleGAT(input_size=173).to(device)
    
    criterion_app = FocalLoss(alpha=0.25, gamma=2.0)
    criterion_avoid = FocalLoss(alpha=0.75, gamma=2.0)
    
    optimizer = optim.Adam(model.parameters(), lr=0.0005, weight_decay=1e-5)
    best_loss = float('inf')
    patience = 10
    trigger_times = 0
    
    for epoch in range(epochs):
        model.train()
        total_train_loss = 0
        for batch_x, batch_y_app, batch_y_avoid in train_loader:
            batch_x, batch_y_app, batch_y_avoid = batch_x.to(device), batch_y_app.to(device), batch_y_avoid.to(device)
            optimizer.zero_grad()
            
            # V10.0: 前向传播，包含奇点检测
            out_app, out_avoid, latent, _, singularity_prob = model(batch_x)
            
            # 计算基础损失
            loss_app = criterion_app(out_app, batch_y_app)
            loss_avoid = criterion_avoid(out_avoid, batch_y_avoid)
            loss_cont = contrastive_loss(latent, batch_y_app)
            
            # V10.0: 极端奖励加权 (13 命中以上权重提升 100 倍)
            # 估算每个样本的命中数
            with torch.no_grad():
                preds = torch.sigmoid(out_app) > 0.5
                hits = torch.sum(preds * batch_y_app, dim=1)
                # 生成权重掩码: 命中 >= 13 的样本权重设为 100，其余为 1
                boost_weights = torch.where(hits >= 13, torch.tensor(100.0, device=device), torch.tensor(1.0, device=device))
            
            # 应用加权损失
            weighted_loss_app = (F.binary_cross_entropy_with_logits(out_app, batch_y_app, reduction='none').mean(dim=1) * boost_weights).mean()
            
            # 奇点检测损失 (目标：当命中 > 12 时，singularity_prob 应趋向 1)
            singularity_target = (hits > 12).float().unsqueeze(1)
            loss_singularity = F.binary_cross_entropy(singularity_prob, singularity_target)
            
            total_loss = weighted_loss_app + loss_avoid + 0.1 * loss_cont + 0.5 * loss_singularity
            
            total_loss.backward()
            optimizer.step()
            total_train_loss += total_loss.item()
            
        model.eval()
        total_val_loss = 0
        with torch.no_grad():
            for batch_x, batch_y_app, batch_y_avoid in val_loader:
                batch_x, batch_y_app, batch_y_avoid = batch_x.to(device), batch_y_app.to(device), batch_y_avoid.to(device)
                out_app, out_avoid, _, _, _ = model(batch_x)
                total_val_loss += (criterion_app(out_app, batch_y_app) + criterion_avoid(out_avoid, batch_y_avoid)).item()
        
        avg_val_loss = total_val_loss / len(val_loader)
        print(f"Epoch [{epoch+1}/{epochs}], Train Loss: {total_train_loss/len(train_loader):.4f}, Val Loss: {avg_val_loss:.4f}")
        
        if avg_val_loss < best_loss:
            best_loss = avg_val_loss
            trigger_times = 0
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            torch.save(model.state_dict(), save_path)
        else:
            trigger_times += 1
            if trigger_times >= patience:
                print(f"Early stopping at epoch {epoch+1}")
                break
    return model

def predict_next(recent_nums_list, model_path='models/lstm_weights.pth', loss_history=None):
    """
    V10.0: 返回 prob_app, prob_avoid, expert_weights, singularity_prob
    """
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = RegimeEnsembleGAT(input_size=173).to(device)
    if os.path.exists(model_path):
        try:
            model.load_state_dict(torch.load(model_path, map_location=device))
        except:
            print("Warning: Model weights mismatch. Using initialized weights.")
    model.eval()
    
    T = 0.5
    
    with torch.no_grad():
        current_omissions = [0] * 80
        feature_list = []
        for nums in recent_nums_list:
            feat = get_features(nums, current_omissions)
            feature_list.append(feat)
            new_o = [o + 1 for o in current_omissions]
            for n in nums:
                if 1 <= n <= 80: new_o[n-1] = 0
            current_omissions = new_o
            
        input_features = feature_list[-10:] if len(feature_list) >= 10 else [feature_list[0]] * (10-len(feature_list)) + feature_list
        x = torch.tensor(np.array(input_features), dtype=torch.float32).unsqueeze(0).to(device)
        
        lh_tensor = None
        if loss_history is not None:
            lh_tensor = torch.tensor(np.array(loss_history), dtype=torch.float32).unsqueeze(0).to(device)
        
        # V10.0: 前向传播
        out_app, out_avoid, _, weights, singularity_prob = model(x, lh_tensor)
        
        prob_app = torch.sigmoid(out_app / T).cpu().numpy()[0]
        prob_avoid = torch.sigmoid(out_avoid / T).cpu().numpy()[0]
        expert_weights = weights.cpu().numpy()[0]
        s_prob = singularity_prob.cpu().numpy()[0][0]
        
    return prob_app, prob_avoid, expert_weights, s_prob

