import math
import numpy as np
import os

class TorusGrid:
    """
    8x10 Torus Grid mapping for numbers 1-80, using ACE dynamic topology.
    """
    ROWS = 8
    COLS = 10
    MAPPING = None

    @classmethod
    def load_mapping(cls, history_file=None, force_refresh=False):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(base_dir, "number_mapping.npy")
        
        # 检查是否需要重新生成 (如果文件不存在，或者强制刷新)
        should_recompute = not os.path.exists(path) or force_refresh
        
        # V5.1: 如果提供了历史文件，检查映射文件是否过期 (比历史文件旧)
        if not should_recompute and history_file and os.path.exists(history_file):
            history_mtime = os.path.getmtime(history_file)
            mapping_mtime = os.path.getmtime(path)
            # 如果历史文件更新时间远晚于映射文件 (比如差了1小时以上)，考虑刷新
            # 或者简单判断：如果映射文件存在超过 1 天，也考虑刷新
            import time
            if history_mtime > mapping_mtime + 3600 or (time.time() - mapping_mtime) > 86400:
                should_recompute = True

        if should_recompute and history_file:
            print(f"检测到映射文件过期或不存在，正在重新生成实时映射...")
            from .generate_ewma_matrix import generate_ewma_correlation
            matrix_path = os.path.join(base_dir, "correlation_matrix.npy")
            generate_ewma_correlation(history_file, matrix_path, path)
            cls.MAPPING = np.load(path)
        elif cls.MAPPING is None:
            if os.path.exists(path):
                cls.MAPPING = np.load(path)
            else:
                # Fallback to static mapping if file not found
                cls.MAPPING = np.zeros((80, 2))
                for n in range(1, 81):
                    cls.MAPPING[n-1] = [(n-1) % 10, (n-1) // 10]

    @classmethod
    def get_coords(cls, n: int):
        """
        N -> (x, y) using dynamic mapping.
        """
        if cls.MAPPING is None:
            cls.load_mapping()
        if not (1 <= n <= 80):
            raise ValueError(f"Number {n} out of range [1, 80]")
        coords = cls.MAPPING[n-1]
        return coords[0], coords[1]

    @classmethod
    def distance(cls, n1: int, n2: int):
        """
        Torus distance between two numbers based on dynamic mapping.
        """
        x1, y1 = cls.get_coords(n1)
        x2, y2 = cls.get_coords(n2)
        
        dx = abs(x1 - x2)
        dx = min(dx, cls.COLS - dx)
        
        dy = abs(y1 - y2)
        dy = min(dy, cls.ROWS - dy)
        
        return math.sqrt(dx*dx + dy*dy)

    @classmethod
    def get_all_coords(cls):
        """
        Returns all 80 number coordinates as an (80, 2) array.
        """
        if cls.MAPPING is None:
            cls.load_mapping()
        return cls.MAPPING

    @classmethod
    def torus_distance_matrix(cls, coords1, coords2):
        """
        Vectorized torus distance calculation.
        coords1: (M, 2), coords2: (N, 2)
        Returns: (M, N) matrix
        """
        dx = np.abs(coords1[:, np.newaxis, 0] - coords2[np.newaxis, :, 0])
        dx = np.minimum(dx, cls.COLS - dx)
        dy = np.abs(coords1[:, np.newaxis, 1] - coords2[np.newaxis, :, 1])
        dy = np.minimum(dy, cls.ROWS - dy)
        return np.sqrt(dx*dx + dy*dy)

    @classmethod
    def get_neighbors(cls, n: int, radius: float = 1.5):
        """
        Get numbers within a certain radius in the torus grid.
        """
        cls.load_mapping()
        all_coords = cls.MAPPING
        target_coord = all_coords[n-1:n] # (1, 2)
        dists = cls.torus_distance_matrix(all_coords, target_coord).flatten()
        # Find indices where distance <= radius (excluding self)
        neighbor_indices = np.where((dists <= radius) & (dists > 0))[0]
        return (neighbor_indices + 1).tolist()

class LotteryParser:
    """
    Parser for lottery data format: date:YYYY-MM-DD,period:YYYYNNN,numbers:01-02-...-20
    """
    @staticmethod
    def parse_line(line: str):
        line = line.strip()
        if not line:
            return None
        try:
            parts = line.split(',')
            data = {}
            for part in parts:
                k, v = part.split(':', 1)
                data[k] = v
            
            period_id = int(data['period'])
            numbers = [int(n) for n in data['numbers'].split('-')]
            return {
                'period_id': period_id,
                'numbers': sorted(numbers),
                'date': data['date']
            }
        except Exception as e:
            print(f"Error parsing line: {line}. Error: {e}")
            return None

    @staticmethod
    def load_history(file_path: str):
        history = []
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                parsed = LotteryParser.parse_line(line)
                if parsed:
                    history.append(parsed)
        return sorted(history, key=lambda x: x['period_id'])
