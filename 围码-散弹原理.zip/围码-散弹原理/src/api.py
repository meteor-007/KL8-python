from fastapi import FastAPI, HTTPException, Query
from typing import List, Optional
from pydantic import BaseModel, Field
from .storage import StateStore
from .system import ShotgunSystem
import uvicorn

app = FastAPI(title="Happy 8 Adaptive Shotgun Coverage System (V3.0)")

# Initialize storage and system
state_store = StateStore("shotgun_state.json")
system = ShotgunSystem(state_store)

class PredictResponse(BaseModel):
    period_id: int
    base_radius: float
    momentum_v: float
    pool_size: int
    enclosure_pool: List[int]
    coverage: float
    focal_confidences: List[float]
    focal_allocations: List[int]
    prior_gravity_offset: List[float]
    mapping_version: str
    q_efficiency: float

class StateResponse(BaseModel):
    period_id: int
    r_base: float
    integral: float
    prev_error: float
    momentum_v: float
    last_pool_size: int
    last_pool: List[int]
    coverage_history: List[float]

@app.get("/v1/predict/shotgun", response_model=PredictResponse)
async def predict_shotgun(
    period_id: int = Query(..., description="Current period to predict"),
    last_period_id: int = Query(..., description="Previous period ID"),
    last_result: str = Query(..., description="Comma-separated list of 20 winning numbers from last period")
):
    """
    Predict the recommended numbers for the current period using V3.0 Multi-Focal engine.
    """
    try:
        # Parse last_result
        if last_result:
            result_list = [int(n.strip()) for n in last_result.split(',')]
            if len(result_list) != 20:
                raise ValueError("last_result must contain exactly 20 numbers")
        else:
            result_list = []
            
        result = system.predict(period_id, last_period_id, result_list)
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")

@app.get("/v1/state/{period_id}", response_model=StateResponse)
async def get_state(period_id: int):
    """
    Get the internal state snapshot for a specific period.
    """
    snapshot = state_store.get_snapshot(period_id)
    if not snapshot:
        raise HTTPException(status_code=404, detail="State not found for this period")
    
    return {
        "period_id": snapshot.period_id,
        "r_base": snapshot.r_base,
        "integral": snapshot.integral,
        "prev_error": snapshot.prev_error,
        "momentum_v": snapshot.momentum_v,
        "last_pool_size": len(snapshot.last_pool),
        "last_pool": snapshot.last_pool,
        "coverage_history": snapshot.coverage_history
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
