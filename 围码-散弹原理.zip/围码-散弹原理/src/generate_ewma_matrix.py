import numpy as np
from sklearn.manifold import MDS
import os
import sys

# 将父目录添加到 sys.path 以导入 utils
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.utils import LotteryParser

def generate_ewma_correlation(history_file, output_matrix_path, output_mapping_path, alpha=0.1):
    """
    实现 V3.0 的 EWMA 指数加权移动平均关联矩阵
    R_t = (1 - alpha) * R_{t-1} + alpha * (C_t * C_t^T)
    """
    print(f"正在从 {history_file} 读取历史数据...")
    history_data = LotteryParser.load_history(history_file)
    print(f"读取到 {len(history_data)} 期数据。")
    
    # 初始化共现矩阵 (80x80)
    co_occurrence = np.zeros((80, 80))
    
    # 按时间顺序处理历史数据
    print(f"正在计算 EWMA 矩阵 (alpha={alpha})...")
    for period in history_data:
        nums = period['numbers']
        # 创建 one-hot 向量 (1-80 映射到 0-79)
        c = np.zeros(80)
        for n in nums:
            if 1 <= n <= 80:
                c[n-1] = 1
        
        # 矩阵更新: R_t = (1-alpha) * R_{t-1} + alpha * (C_t @ C_t^T)
        c_matrix = np.outer(c, c)
        co_occurrence = (1 - alpha) * co_occurrence + alpha * c_matrix

    # 归一化为相关性矩阵: Corr_ij = Co_ij / sqrt(Co_ii * Co_jj)
    # Co_ii 实际上是加权频率
    freq = np.diag(co_occurrence)
    correlation = np.zeros((80, 80))
    for i in range(80):
        for j in range(80):
            if freq[i] > 0 and freq[j] > 0:
                correlation[i, j] = co_occurrence[i, j] / np.sqrt(freq[i] * freq[j])
            else:
                correlation[i, j] = 0
                
    np.save(output_matrix_path, correlation)
    print(f"已将 EWMA 相关性矩阵保存至 {output_matrix_path}")

    # 逻辑距离矩阵
    logic_dist = 1 - correlation
    logic_dist = np.maximum(logic_dist, 0)
    np.fill_diagonal(logic_dist, 0)

    # MDS 降维映射到 2D 空间
    print("正在执行 MDS 降维嵌入...")
    mds = MDS(n_components=2, dissimilarity='precomputed', random_state=42, 
              normalized_stress='auto', max_iter=3000, n_init=20)
    coords = mds.fit_transform(logic_dist)

    # 缩放到 8x10 网格范围
    coords_min = coords.min(axis=0)
    coords_max = coords.max(axis=0)
    coords_normalized = (coords - coords_min) / (coords_max - coords_min)
    
    final_coords = np.zeros_like(coords_normalized)
    final_coords[:, 0] = coords_normalized[:, 0] * 9.0
    final_coords[:, 1] = coords_normalized[:, 1] * 7.0
    
    np.save(output_mapping_path, final_coords)
    print(f"已将号码映射保存至 {output_mapping_path}")

if __name__ == "__main__":
    history_path = r"D:\Dpanqianyi\Python-Project\data\kl8_history_final.txt"
    matrix_path = r"D:\Dpanqianyi\Python-Project\围码-散弹原理\src\correlation_matrix.npy"
    mapping_path = r"D:\Dpanqianyi\Python-Project\围码-散弹原理\src\number_mapping.npy"
    generate_ewma_correlation(history_path, matrix_path, mapping_path)
