import os
from typing import List, Dict, Optional
import numpy as np
from .models import Snapshot, INITIAL_R_BASE, Q_MAX
from .storage import StateStore
from .engine import MomentumPID, AnchorEngine, ScoringEngine, BayesianController, MultiFocalEngine, DynamicQAllocator
from .set_optimizer import CombinatorialOptimizer, RL_CombinatorialOptimizer, SingularitySetSearcher
from .manifold_engine import ManifoldCollapseEngine

class ShotgunSystem:
    def __init__(self, state_store: StateStore):
        self.state_store = state_store
        self.optimizer = CombinatorialOptimizer(alpha=1.2)
        # V9.0: 初始化流形引擎
        self.manifold_engine = ManifoldCollapseEngine(n_components=3)
        # V10.0: 初始化奇点搜索器
        adj_path = 'src/correlation_matrix.npy'
        if os.path.exists(adj_path):
            self.corr_matrix = np.load(adj_path)
        else:
            self.corr_matrix = np.eye(80)
        self.singularity_searcher = SingularitySetSearcher(self.corr_matrix)

    def predict(self, period_id: int, last_period_id: int, last_result: List[int], history_results: List[List[int]] = None, history_file: str = None) -> Dict:
        """
        V9.0 “流形坍缩”与“态势集成”策略
        """
        # 1. 状态加载
        last_snapshot = self.state_store.get_snapshot(last_period_id)
        
        if last_snapshot:
            current_r_base = last_snapshot.r_base
            integral = last_snapshot.integral
            prev_error = last_snapshot.prev_error
            momentum_v = last_snapshot.momentum_v
            last_pool = last_snapshot.last_pool
            last_hit_periods = list(last_snapshot.last_hit_periods)
            coverage_history = list(last_snapshot.coverage_history)
            loss_history = list(last_snapshot.loss_history)
            periods_processed = len(self.state_store.snapshots)
        else:
            current_r_base = INITIAL_R_BASE
            integral = 0.0
            prev_error = 0.0
            momentum_v = 0.0
            last_pool = []
            last_hit_periods = [0] * 80
            coverage_history = []
            loss_history = [0.5] * 5
            periods_processed = 0

        # 2. 更新最后命中期号
        if last_result:
            for n in last_result:
                if 1 <= n <= 80:
                    last_hit_periods[n-1] = last_period_id

        # 3. 覆盖率更新与 PID 调节
        new_r_base, new_integral, new_error, new_v, coverage = MomentumPID.update(
            current_r_base, integral, prev_error, momentum_v, last_pool, last_result, periods_processed
        )
        
        coverage_history.append(coverage)
        if len(coverage_history) > 20:
            coverage_history.pop(0)
            
        # V9.0: 更新 Loss 历史
        if last_result and last_pool:
            hits = len(set(last_pool) & set(last_result))
            current_loss = 1.0 - (hits / 20.0)
            loss_history.append(float(current_loss))
            if len(loss_history) > 5:
                loss_history.pop(0)

        # 4. 锚点与多焦基准
        anchors = AnchorEngine.generate_anchors(period_id)
        offset = (0.0, 0.0)
        if history_results:
            offset = BayesianController.calculate_offset(history_results)
        s_b, c_b = MultiFocalEngine.get_barycenter_scores(anchors, new_r_base, offset, history_results=history_results, history_file=history_file)

        # 5. V10.0 核心逻辑
        # 5.1 获取深度学习概率 (RegimeEnsembleGAT) 与 奇点概率
        _, prob_app, _, _, expert_weights, singularity_prob = MultiFocalEngine.get_dl_v6_scores(
            history_results, s_b, last_hit_periods, period_id, loss_history=loss_history
        )
        
        # 5.2 V10.0: 使用奇点搜索器 (多起点模拟退火) 生成 32 码池
        # 实时更新历史记录以进行物理惩罚计算
        self.singularity_searcher.history = history_results if history_results else []
        enclosure_pool = self.singularity_searcher.optimize(prob_app, target_size=32)

        # 6. 快照持久化
        new_snapshot = Snapshot(
            period_id=period_id,
            r_base=new_r_base,
            integral=new_integral,
            prev_error=new_error,
            momentum_v=new_v,
            last_pool=enclosure_pool,
            last_hit_periods=last_hit_periods,
            coverage_history=coverage_history,
            loss_history=loss_history
        )
        self.state_store.save_snapshot(new_snapshot)

        # 7. 返回结果
        return {
            "period_id": period_id,
            "base_radius": round(new_r_base, 4),
            "momentum_v": round(new_v, 4),
            "enclosure_pool": enclosure_pool,
            "pool_size": len(enclosure_pool),
            "expert_weights": {
                "Hot": round(float(expert_weights[0]), 3),
                "Ice": round(float(expert_weights[1]), 3),
                "Signal": round(float(expert_weights[2]), 3),
                "Structure": round(float(expert_weights[3]), 3)
            },
            "singularity_prob": round(float(singularity_prob), 4),
            "mapping_version": "Singularity-V10.0"
        }
