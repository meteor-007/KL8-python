from dataclasses import dataclass, field
from typing import List

# --- Constants ---
BASE_ANCHORS = [1, 5, 9, 16, 20, 27, 31, 35, 40, 44, 48, 53, 57, 62, 66, 70, 73, 75, 78, 80]
# V1.3 coordinates for the base anchors to maintain shotgun pattern
BASE_ANCHOR_COORDS = [( (a-1)%10, (a-1)//10 ) for a in BASE_ANCHORS]
TARGET_COVERAGE = 0.40  # V4.0: 瞄准 24 个号码中命中 8 个 (8/20 = 0.4)
TARGET_HITS = 20 * TARGET_COVERAGE  # 8
BETA = 1.10
Q_MIN = 24
Q_MAX = 24
R_MIN = 0.5  # V4.0: 强制压缩
R_MAX = 2.0  # V4.0: 强制聚焦
I_MAX = 3.0
KP = 0.5  # V4.0: 降低比例增益，防止剧烈波动
KI = 0.05
KD = 0.8  # V4.0: 增加微分增益，增强阻尼
WARMUP_PERIODS = 5
INITIAL_R_BASE = 1.5  # V4.0: 调低初始值以适应更小的半径

# --- V3.0 & V4.0 Constants ---
MU_MOMENTUM = 0.7   # 动量系数
ALPHA_EWMA = 0.1    # EWMA 衰减因子
FOCAL_WEIGHTS_DEFAULT = [0.4, 0.4, 0.2] # Barycenter, Momentum, Entropy
SHARPNESS_FACTOR = 3.0  # V4.0: 进一步增强锐化

@dataclass
class Snapshot:
    period_id: int
    r_base: float
    integral: float
    prev_error: float
    momentum_v: float = 0.0
    last_pool: List[int] = field(default_factory=list)
    # 存储每个号码上次命中的期号，用于熵值焦计算
    last_hit_periods: List[int] = field(default_factory=lambda: [0]*80)
    # 存储近期覆盖率，用于动量焦计算
    coverage_history: List[float] = field(default_factory=list)
    # V9.0: 存储最近 5 期的 Loss 分布
    loss_history: List[float] = field(default_factory=lambda: [0.5]*5)

    def to_dict(self):
        return {
            "period_id": self.period_id,
            "r_base": self.r_base,
            "integral": self.integral,
            "prev_error": self.prev_error,
            "momentum_v": self.momentum_v,
            "last_pool": self.last_pool,
            "last_hit_periods": self.last_hit_periods,
            "coverage_history": self.coverage_history,
            "loss_history": self.loss_history
        }

    @classmethod
    def from_dict(cls, data: dict):
        return cls(
            period_id=data["period_id"],
            r_base=data["r_base"],
            integral=data["integral"],
            prev_error=data["prev_error"],
            momentum_v=data.get("momentum_v", 0.0),
            last_pool=data.get("last_pool", []),
            last_hit_periods=data.get("last_hit_periods", [0]*80),
            coverage_history=data.get("coverage_history", []),
            loss_history=data.get("loss_history", [0.5]*5)
        )
