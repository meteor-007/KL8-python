import os
import pandas as pd
import numpy as np
from typing import List, Dict
from .utils import LotteryParser
from .storage import StateStore
from .system import ShotgunSystem

class Backtester:
    def __init__(self, history_file: str, state_file: str = "backtest_state.json"):
        self.history_file = history_file
        self.state_file = state_file
        if os.path.exists(self.state_file):
            os.remove(self.state_file)
        self.state_store = StateStore(self.state_file)
        self.system = ShotgunSystem(self.state_store)
        self.history = LotteryParser.load_history(history_file)

    def run(self, limit: int = 500):
        total = len(self.history)
        start_idx = max(0, total - limit)
        print(f"开始 V8.0 “奇点”图网络系统回测，样本量: {total - start_idx} 期...")
        results = []
        
        for i in range(start_idx, total):
            curr_data = self.history[i]
            period_id = curr_data['period_id']
            winning_numbers = curr_data['numbers']
            
            if i == 0:
                last_period_id = 0
                last_result = []
            else:
                last_data = self.history[i-1]
                last_period_id = last_data['period_id']
                last_result = last_data['numbers']
                
            history_results = [h['numbers'] for h in self.history[max(0, i-20):i]]
            prediction = self.system.predict(period_id, last_period_id, last_result, history_results=history_results)
            
            pool = prediction['enclosure_pool']
            hits = len(set(pool) & set(winning_numbers))
            coverage = hits / 20.0
            
            res = {
                "period_id": period_id,
                "hits": hits,
                "pool_size": len(pool),
                "coverage": coverage,
                "radius": prediction['base_radius']
            }
            results.append(res)
            
        return pd.DataFrame(results)

    def analyze(self, df: pd.DataFrame):
        # 核心指标
        avg_hits = df['hits'].mean()
        hit_std = df['hits'].std()
        
        # 命中分布
        hit_dist = df['hits'].value_counts().sort_index().to_dict()
        
        # 低命中定义 (<= 5)
        low_hit_ratio = (df['hits'] <= 5).mean()
        
        # 高命中定义 (>= 10)
        high_hit_ratio = (df['hits'] >= 10).mean()
        
        # V10.0: 奇点爆发定义 (>= 13)
        singularity_ratio = (df['hits'] >= 13).mean()
        
        metrics = {
            "V10.0 平均命中 (32码)": round(avg_hits, 4),
            "命中标准差": round(hit_std, 4),
            "平均覆盖率": f"{df['coverage'].mean()*100:.2f}%",
            "低命中率 (<= 5)": f"{low_hit_ratio*100:.2f}%",
            "高命中率 (>= 10)": f"{high_hit_ratio*100:.2f}%",
            "奇点爆发率 (>= 13)": f"{singularity_ratio*100:.2f}%",
            "最大连续低迷 (Hits <= 5)": self._calculate_max_drawdown(df),
            "平均系统基准半径": round(df['radius'].mean(), 4)
        }
        
        return metrics

    def _calculate_max_drawdown(self, df: pd.DataFrame):
        low_hits = df['hits'] <= 5
        max_run = 0
        current_run = 0
        for val in low_hits:
            if val:
                current_run += 1
                max_run = max(max_run, current_run)
            else:
                current_run = 0
        return max_run

if __name__ == "__main__":
    history_path = r"D:\Dpanqianyi\Python-Project\data\kl8_history_final.txt"
    tester = Backtester(history_path)
    df = tester.run(limit=300) # 回测最近 300 期
    metrics = tester.analyze(df)
    
    print("\n--- V8.0 “奇点”图网络与组合优化回测分析报告 ---")
    for k, v in metrics.items():
        print(f"{k}: {v}")
    
    df.to_csv("backtest_results.csv", index=False)
    print("\n详细结果已保存至 backtest_results.csv")
