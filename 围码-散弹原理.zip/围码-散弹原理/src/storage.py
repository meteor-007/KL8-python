import json
import os
from typing import Optional
from .models import Snapshot

class StateStore:
    """
    Persistent storage for Snapshots using a JSON file.
    """
    def __init__(self, file_path: str = "state_store.json"):
        self.file_path = file_path
        self.snapshots = {}
        self._load()

    def _load(self):
        if os.path.exists(self.file_path):
            with open(self.file_path, 'r', encoding='utf-8') as f:
                try:
                    data = json.load(f)
                    for pid_str, snap_data in data.items():
                        self.snapshots[int(pid_str)] = Snapshot.from_dict(snap_data)
                except json.JSONDecodeError:
                    self.snapshots = {}

    def _save(self):
        data = {str(pid): snap.to_dict() for pid, snap in self.snapshots.items()}
        with open(self.file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4)

    def get_snapshot(self, period_id: int) -> Optional[Snapshot]:
        return self.snapshots.get(period_id)

    def save_snapshot(self, snapshot: Snapshot):
        self.snapshots[snapshot.period_id] = snapshot
        self._save()

    def get_latest_period_id(self) -> Optional[int]:
        if not self.snapshots:
            return None
        return max(self.snapshots.keys())
