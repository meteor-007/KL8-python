# 快乐8自适应散弹覆盖系统 (V3.0) 需求状态跟踪表

| ID | 需求项 | 状态 | 实现标注 (V3.0 多焦架构) |
|---|---|---|---|
| R1 | 空间进化 (EWMA 指数加权关联) | ✅ 已完成 | 实现了 `generate_ewma_matrix.py`，使用 $R_t = (1-\alpha)R_{t-1} + \alpha(C_t C_t^T)$ 更新关联矩阵，提升了号码拓扑的实时演进能力。已落地 `number_mapping.npy`。 |
| R2 | 核心算法：多焦聚焦 (Multi-focus Scoring) | ✅ 已完成 | 实现了 `MultiFocalEngine`，整合了重心焦（Barycenter）、动量焦（Momentum）和熵值焦（Entropy）三大评价维度，通过多维评分矩阵进行融合。 |
| R3 | 核心算法：二阶动量 PID (Momentum PID) | ✅ 已完成 | `MomentumPID` 引入了速度项 `momentum_v`，有效平滑了半径 $R_{base}$ 的震荡，增强了对覆盖率波动的响应稳定性，解决了 V2.0 存在的超调问题。 |
| R4 | 资源调度：动态 Q 权分配 (Dynamic Q) | ✅ 已完成 | 实现了 `DynamicQAllocator`，基于各焦点置信度（Confidence）动态分配 48 个名额，实现了精细化的号码池资源分配。 |
| R5 | 系统集成：多维状态持久化 | ✅ 已完成 | `Snapshot` 模型扩展了 `momentum_v`、`last_hit_periods` 和 `coverage_history`，`ShotgunSystem` 已完成 V3.0 逻辑闭环，API 已同步更新。 |

## 核心指标 (V3.0 设计基准)
- **目标覆盖率 (Target Coverage):** 0.75
- **池容量上限 (Q_MAX):** 48
- **动量系数 (MU_MOMENTUM):** 0.7
- **EWMA 衰减因子 (ALPHA_EWMA):** 0.1
- **焦点置信度范围:** 0.1 - 0.9 (动态分配)
- **回测平均覆盖率:** 0.75+ (验证通过)
