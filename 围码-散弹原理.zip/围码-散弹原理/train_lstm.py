from src.dl_model import train_model, predict_next, preprocess_data
import os
import torch
import numpy as np

def main():
    # 数据路径
    history_path = r"D:\Dpanqianyi\Python-Project\data\kl8_history_final.txt"
    # 模型权重保存路径
    save_path = os.path.join("models", "lstm_weights.pth")
    
    # 1. 训练模型
    print("--- 开始 V10.0 “奇点”模型强化训练 ---")
    train_model(
        file_path=history_path,
        save_path=save_path,
        epochs=10,
        batch_size=32,
        seq_len=10,
        val_split=0.1
    )
    print("--- 训练完成 ---")

    # 2. 验证预测功能
    print("\n--- 验证预测功能 ---")
    from src.utils import LotteryParser
    history = LotteryParser.load_history(history_path)
    if len(history) >= 10:
        recent_nums_list = [p['numbers'] for p in history[-10:]]
        prob_app, prob_avoid, expert_weights, s_prob = predict_next(recent_nums_list, model_path=save_path)

        # 找出概率最高的前 10 个号码
        top_indices = prob_app.argsort()[-10:][::-1]
        top_numbers = [idx + 1 for idx in top_indices]
        print(f"下期 [出现概率] 最高前 10: {top_numbers}")
        print(f"当前奇点爆发概率: {s_prob:.4f}")
        print(f"专家权重: {expert_weights}")
    else:
        print("数据量不足，无法进行验证预测。")

if __name__ == "__main__":
    main()
