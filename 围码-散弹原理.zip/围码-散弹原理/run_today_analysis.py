import json
import os
from src.storage import StateStore
from src.system import ShotgunSystem
from src.utils import LotteryParser

def run_today_analysis():
    # 1. 加载历史数据并获取最新一期
    history_path = r"D:\Dpanqianyi\Python-Project\data\kl8_history_final.txt"
    history = LotteryParser.load_history(history_path)
    last_data = history[-1]
    
    last_period_id = last_data['period_id']
    last_result = last_data['numbers']
    # 预测下一期
    today_period_id = last_period_id + 1
    
    # 2. 初始化系统
    state_store = StateStore("shotgun_state.json")
    system = ShotgunSystem(state_store)
    
    # 3. 获取前 20 期历史用于计算
    history_results = [h['numbers'] for h in history[-20:]]
    
    # 4. 执行预测
    print(f"正在分析第 {today_period_id} 期 (基于 {last_period_id} 期结果)...")
    prediction = system.predict(today_period_id, last_period_id, last_result, history_results=history_results)
    
    # 5. 生成详细报告
    report = f"""# 快乐8散弹覆盖系统 V8.0 “奇点” - 每日分析报告
日期: {last_data['date']} (预测下一期: {today_period_id})
--------------------------------------------------
## 核心参数
- 架构版本: {prediction.get('mapping_version')}
- 推荐池大小 (Q): {prediction.get('pool_size')} 码
- 系统基准半径 (R_base): {prediction.get('base_radius')}
- 系统动量 (Momentum_V): {prediction.get('momentum_v')}

## 最终优化输出 (Enclosure Pool) - 共 {prediction.get('pool_size')} 个
{", ".join(map(str, prediction.get('enclosure_pool', [])))}

--------------------------------------------------
注: 本期预测由 GAT 图卷积网络与组合优化器(Set Optimizer)联合生成。
报告生成时间: 2026-05-03
"""
    
    # 6. 保存到文件
    output_file = f"daily_analysis_{today_period_id}.md"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(report)
    
    print(f"分析完成！报告已生成: {output_file}")
    print("\n--- 推荐号码预览 ---")
    print(", ".join(map(str, prediction.get('enclosure_pool', []))))

if __name__ == "__main__":
    run_today_analysis()
