import numpy as np
import pandas as pd
from sklearn.manifold import MDS
import os

def generate_correlation_data(history_file, output_matrix_path, output_mapping_path):
    print(f"Reading history from {history_file}...")
    history = []
    with open(history_file, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line: continue
            try:
                # Format: date:YYYY-MM-DD,period:YYYYNNN,numbers:01-02-...-20
                parts = line.split(',')
                numbers_part = [p for p in parts if p.startswith('numbers:')][0]
                numbers = [int(n) for n in numbers_part.split(':')[1].split('-')]
                history.append(numbers)
            except Exception as e:
                print(f"Error parsing line: {line}. Error: {e}")

    print(f"Read {len(history)} periods.")
    
    # Only use recent 150 periods for short-term non-randomness capture
    history = history[:150]
    print(f"Using recent {len(history)} periods for matrix generation.")
    
    # 1. Co-occurrence Matrix
    co_occurrence = np.zeros((80, 80))
    for numbers in history:
        for i in range(len(numbers)):
            for j in range(i + 1, len(numbers)):
                n1, n2 = numbers[i], numbers[j]
                co_occurrence[n1-1, n2-1] += 1
                co_occurrence[n2-1, n1-1] += 1
    
    # Fill diagonal with frequency of each number
    freq = np.zeros(80)
    for numbers in history:
        for n in numbers:
            freq[n-1] += 1
    for i in range(80):
        co_occurrence[i, i] = freq[i]

    # 2. Correlation Matrix (Cosine Similarity for co-occurrence)
    # R_ij = C_ij / sqrt(C_ii * C_jj)
    correlation = np.zeros((80, 80))
    for i in range(80):
        for j in range(80):
            if freq[i] > 0 and freq[j] > 0:
                correlation[i, j] = co_occurrence[i, j] / np.sqrt(freq[i] * freq[j])
            else:
                correlation[i, j] = 0
    
    np.save(output_matrix_path, correlation)
    print(f"Saved correlation matrix to {output_matrix_path}")

    # 3. Logic Distance Matrix
    logic_dist = 1 - correlation
    # Ensure distance is non-negative and symmetric
    logic_dist = np.maximum(logic_dist, 0)
    np.fill_diagonal(logic_dist, 0)

    # 4. MDS Embedding to 2D
    print("Running MDS embedding (enhanced iterations)...")
    mds = MDS(n_components=2, dissimilarity='precomputed', random_state=42, normalized_stress='auto', max_iter=3000, n_init=20)
    coords = mds.fit_transform(logic_dist)

    # 5. Scale to 8x10 Grid
    # Normalize to [0, 1]
    coords_min = coords.min(axis=0)
    coords_max = coords.max(axis=0)
    coords_normalized = (coords - coords_min) / (coords_max - coords_min)
    
    # Map to [0, 9] for x and [0, 7] for y
    final_coords = np.zeros_like(coords_normalized)
    final_coords[:, 0] = coords_normalized[:, 0] * 9.0
    final_coords[:, 1] = coords_normalized[:, 1] * 7.0
    
    np.save(output_mapping_path, final_coords)
    print(f"Saved number mapping to {output_mapping_path}")

if __name__ == "__main__":
    history_path = r"D:\Dpanqianyi\Python-Project\data\kl8_history_final.txt"
    matrix_path = r"D:\Dpanqianyi\Python-Project\围码-散弹原理\src\correlation_matrix.npy"
    mapping_path = r"D:\Dpanqianyi\Python-Project\围码-散弹原理\src\number_mapping.npy"
    generate_correlation_data(history_path, matrix_path, mapping_path)
